<?php

if (!isset($_SESSION))
    session_start();

if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    header("Location: clientes.php");
    die();
}

if (isset($_POST['confirmar'])) {

    include("lib/conexao.php");
    $id = intval($_GET['id']);

    $sql_cliente = "SELECT foto FROM clientes WHERE id = '$id'";
    $query_cliente = $mysqli->query($sql_cliente) or die($mysqli->error);
    $cliente = $query_cliente->fetch_assoc();

    $sql_code = "DELETE FROM clientes WHERE id = '$id'";
    $sql_query = $mysqli->query($sql_code) or die($mysqli->error);

    if ($sql_query) {

        if (!empty($cliente['foto']))
            unlink($cliente['foto']);

        echo '
            <!DOCTYPE html>
            <html lang="en">
            
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Cliente Deletado</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        padding: 20px;
                        text-align: center;
                    }
            
                    h1 {
                        color: #2ecc71; /* Verde para indicar sucesso */
                    }
            
                    a {
                        text-decoration: none;
                        color: #3498db; /* Azul para links */
                    }
            
                    a:hover {
                        text-decoration: underline;
                    }
                </style>
            </head>
            
            <body>
                <h1>Cliente deletado com sucesso!</h1>
                <p><a href="clientes.php">Clique aqui</a> para voltar para a lista de clientes.</p>
            </body>
            
            </html>
        ';
        die();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deletar Cliente</title>
    <link rel="stylesheet" href="deletar.css">
</head>
<body>
    <div class="container">
        <h1>Tem certeza que deseja deletar este cliente?</h1>
        
        <form action="" method="post">
            <a href="clientes.php">Não</a>
            <button name="confirmar" value="1" type="submit">Sim</button>
        </form>
    </div>
</body>
</html>