<?php

if (isset($_POST['email']) && isset($_POST['senha'])) {

    include('lib/conexao.php');

    $email = $mysqli->escape_string($_POST['email']);
    $senha = $_POST['senha'];

    $sql_code = "SELECT * FROM clientes WHERE email = '$email'";
    $sql_query = $mysqli->query($sql_code) or die($mysqli->error);

    if ($sql_query->num_rows == 0) {
        $erro_email = "O e-mail informado é incorreto";
    } else {
        $usuario = $sql_query->fetch_assoc();
        if (!password_verify($senha, $usuario['senha'])) {
            $erro_senha = "A senha informada está incorreta";
        } else {
            if (!isset($_SESSION))
                session_start();
            $_SESSION['usuario'] = $usuario['id'];
            $_SESSION['admin'] = $usuario['admin'];
            header("Location: clientes.php");
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar</title>
    <link rel="stylesheet" href="login.css">
</head>

<body>

<form action="" method="POST">
        <h1>Projeto PHP</h1>
        <p>
            <label for="">E-mail</label>
            <input placeholder="Digite seu email" type="text" name="email">
            <?php if(isset($erro_email)) { echo "<span class='erro'>$erro_email</span>"; } ?>
        </p>
        <p>
            <label for="">Senha</label>
            <input placeholder="Digite sua senha" type="password" name="senha">
            <?php if(isset($erro_senha)) { echo "<span class='erro'>$erro_senha</span>"; } ?>
        </p>
        <button type="submit">Entrar</button>
    </form>


</body>

</html>