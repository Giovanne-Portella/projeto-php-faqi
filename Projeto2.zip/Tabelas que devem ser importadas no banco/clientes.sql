-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 22/03/2024 às 00:19
-- Versão do servidor: 8.2.0
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `crud_clientes`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `telefone` varchar(11) DEFAULT NULL,
  `nascimento` date DEFAULT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `admin` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `foto`, `email`, `senha`, `telefone`, `nascimento`, `data`, `admin`) VALUES
(20, 'Arthur', 'arquivos/65fccd08a8bce.png', 'arthur@teste.com', '$2y$10$Mqk385h2MG.m9C4ngRIgQeFXNGPRwAetQ0j8/DI63UVIARYDN41Gm', '51988888888', '2000-12-12', '2024-03-21 21:12:56', '1'),
(14, 'Giovanne Portella Marinho', 'arquivos/65f2205fc516f.jpg', 'giovannepb@hotmail.com', '$2y$10$j4tgaHw6GiGmuot0WOhvSeaWtJ3Bp0D13gop0/7i.rCbxj8XqWzBW', '51995904227', '1997-11-22', '2024-03-13 18:53:35', '1'),
(16, 'Giovanne Portella Marinho', 'arquivos/65f227902fc97.jpg', 'giovannepb@teste.com', '$2y$10$zgSt0/aTAZUHEAFPQ5KMoe2KY.fX3duEhS9PYvGspvxres29S5cY.', '51995904227', '1997-11-22', '2024-03-13 19:21:06', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
